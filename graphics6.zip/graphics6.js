// JavaScript Document
  $(function(){
  	$('form .startbutton').click(function() {
		var canvas = document.getElementById('tutorial');
		var cellsize = 2; //Must be even or 1
		var spacewidth = (canvas.width / cellsize);
		var spaceheight = (canvas.height / cellsize);
		var numbercells = spacewidth * spaceheight;
		var livecells = [];
		var numberlivecells = numbercells / 5;
		var neighbours = [];
		var steps = 0;
		var interval = 0;
		
		// Empty the arrays to get ready for restart.
		function initarrays() {
			livecells = [];
			neighbours = [];
		}
		
		// Empty the arrays to get ready for restart.
		function clearspace() {
			var ctx = canvas.getContext('2d');
			ctx.fillStyle = "rgb(255, 255, 255)";
			ctx.fillRect(0, 0, canvas.width, canvas.height);
		}
	
		// Fill new celxy
		function Celxy(x, y) {
			this.x = x;
			this.y = y; 
		}
		
		// Fill livecells with random cellxy's
		function fillrandom() {
			var count;
			for (count = 0; count < numberlivecells; count++) {
				livecells[count] = new Celxy(Math.floor(Math.random() * spacewidth), Math.floor(Math.random() * spaceheight));
			}
		}
		
		// Fade the old screen a bit to white
		function fadeall() {
			var ctx = canvas.getContext('2d');
			ctx.fillStyle = "rgba(255, 255, 255, 0.05)";
			ctx.fillRect(0, 0, canvas.width, canvas.height);
		}
		
		// Draw the array with livecells
		function drawcells() {
			var ctx = canvas.getContext('2d');
			var count;
			steps += 1;
			ctx.fillStyle = "rgb(128, 128, 0)";
			for (count in livecells) {
				ctx.fillRect(livecells[count].x * cellsize, livecells[count].y * cellsize, cellsize, cellsize);
			}	
		}
		
		// Update the counter
		function updatecounter() {
			$('#teller').text(steps);
		}
		
		// Set all neighbours to zero
		function zeroneighbours() {
			var count;
			for (count = 0; count < numbercells; count++) {
				neighbours[count] = 0;
			}
		}
			
		// Tell neighbours around livecells they have a neighbour
		function countneighbours() {
			var count, thisx, thisy, dx, dy;
			for (count in livecells) {
				thisx = livecells[count].x;
				thisy = livecells[count].y;
				for (dy = -1; dy < 2; dy++) {
					for (dx = -1; dx < 2; dx++) {
						neighbours[(thisy + dy) * spacewidth + thisx + dx]++;
					}
				}
				neighbours[thisy * spacewidth + thisx] += 9;
			}
		}
		
		// Evaluate neighbourscounts for new livecells
		function evalneighbours() {
			var count, thisx, thisy, count2 = 0;
			
			function livecell() {
				thisy = Math.floor(count / spacewidth);
				thisx = count - (thisy * spacewidth);
				livecells[count2] = new Celxy(thisx, thisy);
				count2++;
			}
			
			livecells = [];
			for (count = 0; count < numbercells; count++) {
				switch (neighbours[count]) {
				case 3:
					livecell();
					break;
				case 12:
					livecell();
					break;
				case 13:
					livecell();
					break;
				default:
					break;
				}	
			}
		}
		
		// Animation function
		function animateShape() {
			zeroneighbours();
			countneighbours();
			evalneighbours();
			drawcells();
			updatecounter();
			fadeall();
		}
		
		if (canvas.getContext) {
			initarrays();
			clearspace();
			fillrandom();
			drawcells();
			gogogo=setInterval(animateShape, interval);
		}	else {
			// canvas-unsupported code here
			document.write("If you see this, you&rsquo;d better install Firefox or Chrome or Opera or Safari or &hellip;");
		}
	});
	
	$('form .stopbutton').click(function() {
		clearInterval(gogogo);
	});

});	
